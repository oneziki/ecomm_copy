'use strict';

/**
 *  row controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::row.row');
